# dai-min-webdev
this repository is for WEB DEV Course Assignments and Project.

Name: Min Dai

Graduate student in NEU Align program. 

Heroku link: https://dai-min-webdev.herokuapp.com/

Project link: http://localhost:5000/project/index.html

Assignments link: http://localhost:5000/assignment/index.html

