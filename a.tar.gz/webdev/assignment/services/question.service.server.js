var LocalStrategy = require('passport-local').Strategy;
var cookieParser = require('cookie-parser');
var session = require('express-session');


module.exports = function(app, models){

    var model = models.questionModel;

    app.post('/api/submitQuestion/:uid', submitQuestion);


    /*API implementation*/

    function submitQuestion(req, res) {

        var question = req.body;
		var uid = req.params.uid;
		console.log(uid);
        model
            .saveQuestion(question)
            .then(
                function (newQ) {
                    res.json(newQ);
                },
                function (error) {
                    res.sendStatus(404).send(error);
                }
            );

    }

};
