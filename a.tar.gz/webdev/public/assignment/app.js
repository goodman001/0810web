(function () {
    angular
        .module("WebAppMaker", ["ngRoute", "WbdvDirective", 'textAngular']);
})();