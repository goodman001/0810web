(function() {
    angular
        .module("WebAppMaker")
        .controller("LoginController", LoginController)
        .controller("RegisterController", RegisterController)
        .controller("ProfileController", ProfileController)
		.controller("QuestionListController", QuestionListController)
        .controller("QuestionEditController", QuestionEditController);

    function LoginController($location, UserService) {
        var vm = this;
        vm.login = login;

        function login(username, password) {
            UserService
                // .findUserByCredentials(username, password)
                .login(username, password)
                .then(function (user) {
                        $location.url("/profile");
                    },
                    function (error) {
                        vm.error = "Username does not exist.";
                });
        }
    }

    function RegisterController(UserService, $location, $timeout) {
        var vm = this;
        vm.register = register;

        function register(username, password, vpassword) {
            if (username === undefined || username === null || username === ""
                || password === undefined || password === "") {
                vm.error = "Username and Passwords cannot be empty.";
                return;
            }
            if (password !== vpassword) {
                vm.error = "Password does not match.";
                return;
            }
            UserService
                .findUserByUsername(username)
                .then(
                    function (user) {
                        if (user !== null) {
                            vm.error = "Username already exists.";
                            $timeout(function () {
                                vm.error = null;
                            }, 3000);
                            return;
                        } else {
                            var user = {
                                username: username,
                                password: password,
                                firstName: "",
                                lastName: "",
                                email: ""
                            };
                            // return the promise
                            return UserService
                                .register(user);
                        }
                    })
                .then(
                    function () {
                        $location.url("/profile");
                    });
        }
    }

    function ProfileController($routeParams, $timeout, $location, UserService, loggedin) {
        var vm = this;
        // vm.uid = $routeParams.uid;
        vm.uid = loggedin._id;
        vm.user = loggedin;

        vm.updateUser = updateUser;
        vm.deleteUser = deleteUser;
        vm.logout = logout;

        function deleteUser(user) {
            UserService
                .deleteUser(user._id)
                .then(function () {
                    $location.url('/login');
                }, function () {
                    vm.error = "Unable to remove this user.";
                    $timeout(function () {
                        vm.error = null;
                    }, 3000);
                });
        }

        function updateUser(user) {
            UserService
                .updateUser(user._id, user)
                .then(function () {
                    vm.updated = "Profile changes saved!";
                    $timeout(function () {
                        vm.updated = null;
                    }, 3000);
                });
        }
        
        function logout() {
            UserService
                .logout()
                .then(function () {
                    $location.url('/login');
                })
        }

        function userError(error) {
            vm.error = "User not found";
        }
    }
	function QuestionListController($routeParams, $timeout, $location, UserService, loggedin){
		console.log("question");
        function questionList(){
        }
        
	}
    function QuestionEditController($routeParams, $timeout, $location, UserService,loggedin){
        var vm = this;
        vm.h = "hello";
        vm.options = [{'content':""},{'content':""},{'content':""},{'content':""}];
        vm.uid = loggedin._id;
        
        vm.qtypes = [{"index":1,"content":"select" },{"index":2,"content":"fill"} ];
        vm.title = '';
        vm.qtype = 1; 
        vm.qtypestr = '';
        vm.content = '';
        vm.answer = 0;
        vm.answerfill ="";
        console.log(vm.uid);
        
        vm.removeOption = removeOption;
        vm.toWord = toWord;
        vm.addOption = addOption;
        vm.submit = submit;
        vm.changeOP = changeOP;
        
       
        function changeOP(){
            console.log(vm.qtype);
        }
        function removeOption(index){
            console.log(index);
            vm.options.splice(index, 1);
        }
        function addOption(){
            vm.options.push({'content': ''});
        }
        function toWord(index){
            return String.fromCharCode(65 + index);
        }
        
        if(vm.qtype == 2){
            console.log(vm.qtype);
            var newBlocks = vm.content.match(/\$\$/g) || [];
            vm.answerfill = "lalala";
            console.log(vm.content);
        }
        //console.log(vm.content);
        
        
        function submit(){
            console.log(vm.options);
            
            var question = {
                id: (new Date()).valueOf(),
                qtype: vm.qtype,
                name: vm.title,
                content: vm.content,
                options: vm.options,
                answer: vm.answer
            }
            console.log(question);
            /*UserService
                .createQuestion(question,vm.uid)
                .then(function () {
                    vm.updated = "Question saved!";
                    $timeout(function () {
                        vm.updated = null;
                    }, 3000);
                });
            */
        }
        
    }
})();